package person.vehicles;

public class Bike {
public int color;
private int speed;
protected int model;
int year;

public Bike() {
	
}

public Bike(int color, int speed, int model, int year) {
	super();
	this.color = color;
	this.speed = speed;
	this.model = model;
	this.year = year;
}

}

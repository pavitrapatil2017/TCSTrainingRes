package person.vehicles;

public class Car {
int seatCapacity;
private int cspeed;
protected int model;


public Car() {
	
}
void display()
{
	System.out.println(seatCapacity+"  "cspeed)
}

public Car(int seatCapacity, int cspeed, int model) {
	super();
	this.seatCapacity = seatCapacity;
	this.cspeed = cspeed;
	this.model = model;
}


}

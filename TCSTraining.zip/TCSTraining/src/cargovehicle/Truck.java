package cargovehicle;

public class Truck {
int cargoCapacity;

public Truck() {
	
}

public Truck(int cargoCapacity) {
	super();
	this.cargoCapacity = cargoCapacity;
}

public int getCargoCapacity() {
	return cargoCapacity;
}

public void setCargoCapacity(int cargoCapacity) {
	this.cargoCapacity = cargoCapacity;
}


}

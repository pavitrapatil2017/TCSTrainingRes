
public class TestPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//when we create an object memory will be allocated for member variables
		//not for member functions
		Point point=Point.getPointInstance();
		System.out.println(point.getX()+" "+point.getY());
		Point point1=Point.getPointInstance();
		System.out.println(point1.getX()+" "+point1.getY());
		System.out.println(Point.count);
	}

}

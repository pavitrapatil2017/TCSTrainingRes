
public class TwoDEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] ex=new int[][] {{1,2},{3,4},{7,8}};
		
		for(int[] x: ex)
		{
			for(int y: x)
			{
				System.out.print(y+" ");
			}
			System.out.println();
		}
		
		
		
	}

}

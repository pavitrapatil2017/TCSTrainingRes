
public class Shape {
	/*data 
	member variables
	data or information*/
	int length, width, height, radious;
	float volume;
	String name, color;
	/*functionality
	member functions
	functionalities*/
	void draw(){}
	void findArea(){}
	void displayDetails(){
System.out.println(length+" "+width+" "+height+" "+radious+" "+volume+" "+name+" "+color);
	}
	public static void main(String[] args)
	{
		Shape shape=new Shape();
		shape.displayDetails();
		System.out.println("Hello ......");
	}
}

package demo;

import java.util.StringTokenizer;

public class EncapsulationDemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee employee=new Employee("mahesh",1234,76532.876);

Employee employee1=new Employee("mahesh",1234,76532.876);
System.out.println(employee);
//employee=new Employee("Mahesh Kumar",1234, 76532.876);
//employee.setEmpName("Mahesh Kumar");
System.out.println(employee);
//employee.setSalary(80000.98);
//System.out.println(employee);

String s=new String("Nitish");
String s1=new String("Nitish");
if(s==s1)
{
	System.out.println("same");
}else
	System.out.println("not same");


/*if(s.equals(s1))
{
	System.out.println("same");
}else
	System.out.println("not same");*/


if(employee.equals(employee1))
{
	System.out.println("same");
}else
	System.out.println("not same");





String n1="Pavitra";//autoboxing
String n2="Pavitra";

if(n1==n2)
{
	System.out.println("same");
}else 
	System.out.println("nooo");

StringBuffer buff=new StringBuffer("Hello");
buff.append("World");
System.out.println(buff);
buff.insert(0, "boss");
System.out.println(buff);
String s3=buff.toString();

StringTokenizer st=new StringTokenizer("this is java, program to explain, java concepts",",");
while(st.hasMoreElements())
{
	System.out.println(st.nextToken());
}
	}

}


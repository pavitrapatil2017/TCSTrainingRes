import java.util.Scanner;

import cargovehicle.*;
import person.vehicles.*;

public class TestPackage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ship ship=new Ship();
		Car car=new Car();
		Bike bike=new Bike();
		Truck truck=new Truck();
		
		String s;
		char op;
		Scanner sn=new Scanner(System.in);
		do {
		System.out.println("Enter day");
		s=sn.next();
		switch(s)
		{
		case "Monday" : System.out.println("start of week");
		break;
		case "Tuesday" : System.out.println("second day of week");
		break;
		case "Wednesday" : 
		case "Thursday" : System.out.println("Mid of Week");
		break;
		case "Friday" : System.out.println("last working day");
		break;
		case "Saturday" :
		case "Sunday": System.out.println("week end");
		break;
		default: System.out.println("Default");
		
		}
		System.out.println("do you want to continue then press y");
		op=sn.next().charAt(0);
		}while(op=='y'||op=='Y');
		
	/*	
		int x=32,y=16;
			int r=x>>3;// 100000
						//10000
						// 1000
			System.out.println(r);
			int res=0x101;
			
			long num=12_45_56_123;
			System.out.println(num);
			
			int ter=x<10?x++:--x;
			System.out.println("++++"+ter);
			*/
	/*	 
		int x=100;
		System.out.println(x++);//print and then x=x+1
		System.out.println(x);
		System.out.println(++x);//x=x+1 and then it prints
		
		
		
		System.out.println(x++ + ++x - --x + x--);
		//                 102+104-  103 + 103 
*/	}

}

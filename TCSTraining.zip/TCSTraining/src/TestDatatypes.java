import java.util.Scanner;

public class TestDatatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//local variables
int number=9;
float marks=56.09f;
double salary=78653.9873;
boolean flag=true;
String name="Nitish";
char grade='A';
short age=7;
long number1=8763233;


Scanner scanner =new Scanner(System.in);
number=scanner.nextInt();
marks=scanner.nextFloat();
salary=scanner.nextDouble();
flag=scanner.nextBoolean();
name=scanner.next();
grade=scanner.next().charAt(0);
age=scanner.nextShort();
number1=scanner.nextLong();

System.out.println(number+"   "+marks+"  "+salary+" "+flag+" "+name+" "+grade+" "+number1+" "+age);

	}

}

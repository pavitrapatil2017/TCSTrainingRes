import cargovehicle.Ship;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] number= {10,20,30};
		int x=100;
		for(int i=0;i<number.length;i++)
		{
			System.out.println(number[i]);
		}
		number=new int[] {1,2,3,4,5};
		
		for(int i=0;i<number.length;i++)
		{
			System.out.println(number[i]);
		}
		number=new int[10];
		
		for(int i=0;i<number.length;i++)
		{
			number[i]=x++;
		}
		for(int value : number)
		{
			System.out.println(value);
		}
		Ship[] s=new Ship[5];
		for(int i=0;i<s.length;i++)
		{
			s[i]=new Ship(100);
		}
		
		for(Ship s1 : s)
		{
			System.out.println(s1);
		}
	}

}


public class WrapperClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer intg=678;//auto boxing
			//Integer integer=new Integer("100");//boxing
		Integer integer=Integer.valueOf(100);
		System.out.println(integer);
			Float flt=new Float(45.78);
			System.out.println(flt);
			int num=integer+200;//deboxing
			System.out.println(num);
			String sample="123";
			String sample1="1234";
			int result=Integer.parseInt(sample);
			int result1=Integer.parseInt(sample1);
			
			int sum=result+result1;
			System.out.println(sum);
	}

}

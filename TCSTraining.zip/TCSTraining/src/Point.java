
public class Point {
	//member variables or instance variables
private int x,y;
private static Point p=new Point();
//methods
static int count;

/*static {
	count=0;
}*/

private Point()
{
	count++;
	System.out.println("construct");
}
private Point (int x, int y)//local variables
{
	count++;
	this.x=x;
	this.y=y;
}

public int getX(){
	return x;
}
public int getY()
{
	return y;
}
public static Point getPointInstance()
{
	return p;
}

public static void main(String[] args) {
	// TODO Auto-generated method stub
	//when we create an object memory will be allocated for member variables
	//not for member functions
	/*Point point=new Point();
	System.out.println(point.getX()+" "+point.getY());
	Point point1=new Point(100,200);
	System.out.println(point1.getX()+" "+point1.getY());*/
}

}

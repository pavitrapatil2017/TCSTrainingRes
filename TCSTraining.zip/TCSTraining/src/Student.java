
public class Student {
String name;
int id;


	public Student(String name, int id) {
	super();
	this.name = name;
	this.id = id;
}
	@Override
	public String toString()
	{
		return name+" "+id;
	}
	
public static void displayAll(Student ...s)//array
{
	for(Student s1 : s) {
		System.out.println(s1);//invokes toString method of object class
	}
		
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student student=new Student("asha",100);
Student student1=new Student("Nisha",200);
Student student2=new Student("gowri",300);
Student student3=new Student("gowri1",3001);

displayAll(student, student1, student2,student3);

	}

}

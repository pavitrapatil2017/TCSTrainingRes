package java8features_day7;

import java.time.LocalDate;

public class NextChristmasTest {
    public static void main(String[] args) {
    LocalDate localDate = LocalDate.now();
    System.out.println("current date : " + localDate);

    localDate = localDate.with(new NextChristmas());
    System.out.println("Next Christmas : " + localDate);
    }
}

//https://ocpj8.javastudyguide.com/ch22.html

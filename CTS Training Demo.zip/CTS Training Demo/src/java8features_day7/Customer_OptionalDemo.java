package java8features_day7;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Customer_OptionalDemo {

	public static Customer getCustomerByEmailId(String email)
	{
		List<Customer> customers=EkartDataBase.getAll();
		return customers.stream().filter(customer->customer.getEmail().equals(email)).findAny().get();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Customer customer=new Customer(101,"john","abc",Arrays.asList("9886003734","9632824564"));
//three static methods of Optional final class are   
//of
//ofNullable
//empty

Optional<Object> emptyOptional=Optional.empty();
System.out.println(emptyOptional);

/*Optional<String> emailOptional=Optional.of(customer.getEmail());
System.out.println(emailOptional);
*/
Optional<String> emailOptional2=Optional.ofNullable(customer.getEmail());
System.out.println(emailOptional2);

if(emailOptional2.isPresent())
{
System.out.println("get method"+emailOptional2.get());
}
System.out.println(emailOptional2.orElse("default@gmail.com"));

//System.out.println(emailOptional2.orElseThrow(()->new IllegalArgumentException("Email not found")));

System.out.println(emailOptional2.map(String::toUpperCase).orElseGet(()->"default Email"));

	}

}

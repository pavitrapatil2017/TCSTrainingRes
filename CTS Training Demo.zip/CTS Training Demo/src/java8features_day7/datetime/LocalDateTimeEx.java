package java8features_day7.datetime;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;

public class LocalDateTimeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 LocalDateTime now = LocalDateTime.now();  
	        System.out.println("Before Formatting: " + now);  
	        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
	        String formatDateTime = now.format(format);  
	        System.out.println("After Formatting: " + formatDateTime); 
	        
	        LocalDateTime a = LocalDateTime.of(2017, 2, 13, 15, 56);    
	        System.out.println("Dayofweek"+a.get(ChronoField.DAY_OF_WEEK));  
	        System.out.println("Dayofyear"+a.get(ChronoField.DAY_OF_YEAR));  
	        System.out.println("Day of Month"+a.get(ChronoField.DAY_OF_MONTH));  
	        System.out.println("Hour of Day"+a.get(ChronoField.HOUR_OF_DAY));  
	        System.out.println("Minute_of_day"+a.get(ChronoField.MINUTE_OF_DAY));  
	        
	        LocalDateTime datetime1 = LocalDateTime.of(2017, 1, 14, 10, 34);  
	        LocalDateTime datetime2 = datetime1.minusDays(100);  
	        System.out.println("Before Formatting: " + datetime2);  
	        DateTimeFormatter format2 = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");  
	        String formatDateTime2 = datetime2.format(format);   
	        System.out.println("After Formatting: " + formatDateTime );  
	        
	        LocalDateTime datetime3 = datetime1.plusDays(120);  
	        System.out.println("Before Formatting: " + datetime3);  
	        
	}

}

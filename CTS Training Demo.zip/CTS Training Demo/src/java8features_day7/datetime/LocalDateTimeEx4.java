package java8features_day7.datetime;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class LocalDateTimeEx4 {
public static void main(String[] arg) {
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
	   LocalDateTime localDateTime = LocalDateTime.now();  
	   System.out.println(dtf.format(now));  
	   Date date=new Date();
	   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	  
	   System.out.println(date);
	   System.out.println(formatter.format(date));  
	   System.out.println(Calendar.MAY);
	   System.out.println(Calendar.DAY_OF_MONTH);
	   Calendar calendar=Calendar.getInstance();
	   System.out.println(calendar);
	   System.out.println(calendar.DAY_OF_MONTH);
	   
		  } 
}

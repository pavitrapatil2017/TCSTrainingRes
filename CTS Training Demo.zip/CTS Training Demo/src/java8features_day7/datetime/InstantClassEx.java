package java8features_day7.datetime;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

public class InstantClassEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Instant inst = Instant.parse("2017-02-03T10:37:30.00Z");  
		    System.out.println(inst);  

		    Instant instant = Instant.now();  
		    System.out.println(instant);   
		    
		    Instant instant1 = Instant.parse("2017-02-03T11:25:30.00Z");  
		    instant = instant1.minus(Duration.ofDays(125));  
		    System.out.println(instant);   
		    
		    Instant inst1 = Instant.parse("2017-02-03T11:25:30.00Z");  
		    Instant inst2 = inst1.plus(Duration.ofDays(125));  
		    System.out.println(inst2);  
		    
		    Instant inst3 = Instant.parse("2017-02-03T11:35:30.00Z");  
		    System.out.println(inst3.isSupported(ChronoUnit.DAYS));  
		    System.out.println(inst3.isSupported(ChronoUnit.YEARS));      

	}

}

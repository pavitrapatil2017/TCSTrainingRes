package java8features_day7.datetime;

import java.time.OffsetTime;
import java.time.temporal.ChronoField;

public class OffsetDateTimeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OffsetTime offset = OffsetTime.now();  
		System.out.println(offset);
	    int h = offset.get(ChronoField.HOUR_OF_DAY);  
	    System.out.println(h);  
	    int m = offset.get(ChronoField.MINUTE_OF_DAY);  
	    System.out.println(m);  
	    int s = offset.get(ChronoField.SECOND_OF_DAY);  
	    System.out.println(s);  
	    
	    OffsetTime offset1 = OffsetTime.now();  
	    int h1 = offset1.getHour();  
	    System.out.println(h1+ " hour");  
	    
	    int ms = offset.getMinute();  
	    System.out.println(ms+ " minute");  
	    
	    int ss = offset.getSecond();  
	    System.out.println(ss+ " second");  
	}

}

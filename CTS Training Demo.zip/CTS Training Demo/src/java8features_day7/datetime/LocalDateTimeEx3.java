package java8features_day7.datetime;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class LocalDateTimeEx3 {
	 public static void main(String[] args) {  
		    LocalDate date = LocalDate.of(2017, 1, 13);
		    System.out.println(date);
		    LocalDateTime datetime = date.atTime(1,50,9);      
		    System.out.println(datetime);   
		  }  

}

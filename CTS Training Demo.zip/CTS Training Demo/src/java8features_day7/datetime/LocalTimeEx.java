package java8features_day7.datetime;

import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;  

public class LocalTimeEx {
	  public static void main(String[] args) {  
			    LocalTime time = LocalTime.now();  
			    System.out.println(time);  
			    LocalTime time1 = LocalTime.of(10,43,12);  
			    System.out.println(time1);  
			    
			    LocalTime time4 = LocalTime.of(10,43,12);  
			    System.out.println("11    "+time4);  
			    LocalTime time2=time4.minusHours(2); 
			    System.out.println("22      "+time2);
			    LocalTime time3=time2.minusMinutes(34);  
			    System.out.println("33    "+time3); 
			    
			   LocalTime time6 = LocalTime.of(10,43,12);  
			    System.out.println(time6);  
			    LocalTime time7=time6.plusHours(4);  
			    LocalTime time8=time7.plusMinutes(18);  
			    System.out.println(time8);  
			    
			    System.out.println("Default zone id"+ZoneId.systemDefault());
			    
			    ZoneId zone1 = ZoneId.of("Asia/Kolkata");  
			    ZoneId zone2 = ZoneId.of("Asia/Tokyo");  
			    LocalTime time11 = LocalTime.now(zone1);  
			    System.out.println("India Time Zone: "+time11);  
			    LocalTime time22 = LocalTime.now(zone2);  
			    System.out.println("Japan Time Zone: "+time22);  
			    long hours = ChronoUnit.HOURS.between(time11, time22);  
			    System.out.println("Hours between two Time Zone: "+hours);  
			    long minutes = ChronoUnit.MINUTES.between(time1, time2);  
			    System.out.println("Minutes between two time zone: "+minutes); 
	  }  


}

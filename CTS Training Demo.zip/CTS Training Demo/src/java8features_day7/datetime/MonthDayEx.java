package java8features_day7.datetime;

import java.time.LocalDate;
import java.time.MonthDay;
import java.time.temporal.ChronoField;
import java.time.temporal.ValueRange;

public class MonthDayEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 MonthDay month = MonthDay.now();  
		   LocalDate date = month.atYear(2021);  
		    System.out.println(date);  
		    
		    MonthDay month1 = MonthDay.now();  
		    boolean b = month1.isValidYear(2012);  
		    System.out.println(b); 
		    
		    long n = month.get(ChronoField.MONTH_OF_YEAR);  
		    System.out.println(n);  
		    
		    ValueRange r1 = month.range(ChronoField.MONTH_OF_YEAR);  
		    System.out.println(r1);  
		    ValueRange r2 = month.range(ChronoField.DAY_OF_MONTH);  
		    System.out.println(r2);  
		    
		    
	}

}

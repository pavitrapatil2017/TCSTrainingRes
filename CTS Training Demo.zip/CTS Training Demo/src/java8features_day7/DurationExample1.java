package java8features_day7;

import java.time.Duration;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class DurationExample1 {
  public static void main(String[] args) {  
			   /* Duration d = Duration.between(LocalTime.NOON,LocalTime.MAX);  
			    System.out.println(d.get(ChronoUnit.SECONDS));  
			    System.out.println(LocalTime.NOON);
			    System.out.println(LocalTime.MAX);
			    System.out.println(d.get(ChronoUnit.NANOS));
	  Duration d1 = Duration.between(LocalTime.MAX,LocalTime.NOON);  
	  	      System.out.println(d1.isNegative());  
	 	      Duration d2 = Duration.between(LocalTime.NOON,LocalTime.MAX);  
	              System.out.println(d2.isNegative());   
	              
	            Duration d1 = Duration.between(LocalTime.NOON,LocalTime.MAX);  
	        	    System.out.println(d1.getSeconds());  
	            	    Duration d2 = d1.minus(d1);  
	              	    System.out.println(d2.getSeconds());   */  
 
	              	  Duration d1 = Duration.between(LocalTime.NOON,LocalTime.MAX);  
	              		    System.out.println(d1.getSeconds());  
	                  Duration d2 = d1.plus(d1);  
	              		    System.out.println(d2.getSeconds());  


			    
		  }  


}

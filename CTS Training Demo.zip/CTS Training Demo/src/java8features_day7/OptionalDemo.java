package java8features_day7;

import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Optional<String> optionalString=Optional.empty();
System.out.println(optionalString);
String book=null;
if(book!=null)
{
	System.out.println("not null"+book.toUpperCase());
}else
{
	book="Java 8";
	System.out.println(book.toUpperCase());
}
String book11=null;
optionalString=Optional.ofNullable(book11);
System.out.println("Null optionalstring"+optionalString);

//System.out.println(optionalString.orElse("Java 9").toUpperCase());


String book1=null;
optionalString=Optional.ofNullable(book1);
System.out.println(optionalString.orElse("Java 9").toUpperCase());

	}

}

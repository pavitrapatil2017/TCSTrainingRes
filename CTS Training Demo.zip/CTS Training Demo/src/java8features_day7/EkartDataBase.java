package java8features_day7;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EkartDataBase {
	public static List<Customer> getAll()
	{
		return Stream.of(new Customer(101, "John","john@gmail.com", Arrays.asList("7873312121","1234567891")),
				new Customer(101, "John","john@gmail.com", Arrays.asList("7873312121","1234567891")),
				new Customer(101, "John","john@gmail.com", Arrays.asList("7873312121","1234567891")),
				new Customer(101, "John","john@gmail.com", Arrays.asList("7873312121","1234567891"))
				).collect(Collectors.toList());
	}

}

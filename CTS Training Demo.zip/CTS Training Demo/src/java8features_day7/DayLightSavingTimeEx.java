package java8features_day7;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

public class DayLightSavingTimeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDateTime localDateTime=LocalDateTime.of(2017, Month.MARCH, 12,1,30);
		ZoneId zoneId=ZoneId.of("US/Eastern");
		ZonedDateTime zonedDateTime=ZonedDateTime.of(localDateTime,zoneId);
		System.out.println("spring forward");
		ZonedDateTime jumpOneHour=zonedDateTime.plus(1, ChronoUnit.HOURS);
		System.out.println(zonedDateTime);
		System.out.println(zonedDateTime.toInstant());
		System.out.println(jumpOneHour);
		System.out.println(jumpOneHour.toInstant());
		System.out.println(Duration.between(zonedDateTime, jumpOneHour));
		System.out.println("fall backward");
		System.out.println(jumpOneHour);
		localDateTime=LocalDateTime.of(2017,Month.NOVEMBER,5,1,30);
		zonedDateTime=zonedDateTime.of(localDateTime, zoneId);
		ZonedDateTime fallOneHour=zonedDateTime.plusHours(1);
		System.out.println(zonedDateTime);
		System.out.println(zonedDateTime.toInstant());
		System.out.println(fallOneHour);
		System.out.println(fallOneHour.toInstant());
		System.out.println(Duration.between(zonedDateTime, fallOneHour));
		System.out.println();
		System.out.println(ZonedDateTime.now());
		
	}

}

package java8features_day7.parallelstreams;

import java.util.ArrayList;
import java.util.List;

public class ReduceMethodExample {
	public static void main(String[] a)
	{
		List<Integer> numbers=new ArrayList<Integer>();
		numbers.add(100);
		numbers.add(200);
		numbers.add(300);
		Integer result= numbers.stream().map(n->n).reduce(0,(sum,n)->sum+n);
		System.out.println(result);
		
	}

}

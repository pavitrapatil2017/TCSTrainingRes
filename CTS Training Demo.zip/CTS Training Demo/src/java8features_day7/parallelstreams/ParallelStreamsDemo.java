package java8features_day7.parallelstreams;

import java.util.List;
import java.util.stream.IntStream;

public class ParallelStreamsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start=0;
		long end=0;
		
		start=System.currentTimeMillis();
		IntStream.range(1,100).forEach(System.out::println);
		end=System.currentTimeMillis();
		System.out.println("plain stream took time"+(end-start));
		
		System.out.println("====================");
		
		start=System.currentTimeMillis();
		IntStream.range(1,100).parallel().forEach(System.out::println);
		end=System.currentTimeMillis();
		
		System.out.println("Parallel stream took time"+(end-start));
		
		IntStream.range(1,10).forEach(x->{
			System.out.println("Thread"+Thread.currentThread().getName()+" "+x);
		});
		
		IntStream.range(1,10).parallel().forEach(x->{
			System.out.println("Thread"+Thread.currentThread().getName()+":"+x);
		});
		/*List<Employee> employees=EmployeeDataBase.getEmployees();
		
		start=System.currentTimeMillis();
		double salaryWithStream=employees.stream().map(Employee::getSalary).mapToDouble(i->i).average().getAsDouble();
		end=System.currentTimeMillis();
		
		System.out.println("Normal stream took time"+(end-start)+"Avg Salary :"+salaryWithStream);
		
		
		start=System.currentTimeMillis();
		double salaryWithParallelStream=employees.parallelStream().map(Employee::getSalary).mapToDouble(i->i).average().getAsDouble();
		end=System.currentTimeMillis();
		
		System.out.println("Parallel stream took time"+(end-start)+"Avg Salary:"+salaryWithParallelStream);
		
		*/
		
	}

}

//https://www.youtube.com/watch?v=J7YqYlaev7g

//https://www.zee5.com/tvshows/details/kumkum-bhagya/0-6-127/kumkum-bhagya-episode-571-may-18-2016-full-episode/0-1-34400
	

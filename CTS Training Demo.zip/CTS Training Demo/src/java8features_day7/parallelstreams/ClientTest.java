package java8features_day7.parallelstreams;

import java.util.List;
import java.util.stream.Stream;
import java.util.ArrayList;
public class ClientTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> list=new ArrayList<>();
		list.add(new Student("ab",1)); 
		list.add(new Student("xy",2));
		list.add(new Student("mn",3));
		list.add(new Student("kl",4));
		list.add(new Student("abc",5));
		Stream<Student> parallelStream=list.parallelStream();
		System.out.println("Students data send for processing");
		parallelStream.forEach(s->doProcess(s));
		
			
	}
private static void doProcess(Student s)
{
	System.out.println(s);
}

}

package java8features_day7.parallelstreams;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

//Declaring repeatable annotation Type
@Repeatable(Games.class)
@interface Game
{
	String name();
	String day();
}
//Declaring container for repeatable annotation type
@Retention(RetentionPolicy.RUNTIME)
@interface Games
{
	Game[] value();
}
//Repeating annotation
@Game(name="Cricket",day="Sunday")
@Game(name="Hockey",day="Friday")
@Game(name="Football",day="Saturday")
public class RepeatableAnnotationEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game[] game=RepeatableAnnotationEx.class.getAnnotationsByType(Game.class);
		for(Game game2:game)
		{
			System.out.println(game2.name()+"on"+game2.day());
		}

	}

}

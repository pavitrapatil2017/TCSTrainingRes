package java8features_day7;

import java.util.Arrays;
import java.util.List;

public class ReduceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> words=Arrays.asList("corejava","spring","hibernate");
		String longestword=words.stream().reduce((word1,word2)->word1.length()>word2.length() ? word1:word2)
		.get();
	System.out.println(longestword);
	
	double avgSalary=EmployeeDataBase.getEmployees().stream()
			.filter(employee->employee.getGrade().equalsIgnoreCase("A"))
			.map(employee->employee.getSalary())
			.mapToDouble(i->i)
			.average().getAsDouble();
	System.out.println(avgSalary);
	
	}

}

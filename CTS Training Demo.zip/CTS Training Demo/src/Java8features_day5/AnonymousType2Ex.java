package Java8features_day5;

public class AnonymousType2Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Here we are using Anonymous Inner class
        //that implements a interface i.e. Here Runnable interface
        Runnable r = new Runnable()
        {
            public void run()
            {
                System.out.println("Child Thread");
            }
        };
        Thread t = new Thread(r);
        t.start();
        System.out.println("Main Thread");
	}

}
interface Runnable
{
	public void run();
}

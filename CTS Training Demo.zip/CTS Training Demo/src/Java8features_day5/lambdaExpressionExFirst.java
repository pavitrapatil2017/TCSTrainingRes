package Java8features_day5;

interface MyInterface
{
	void add();
}



public class lambdaExpressionExFirst {
public static void main(String[] ar)
{
	MyInterface myinterface=()->System.out.println("Hello Lambda");
	
	myinterface.add();
	
	
}
}


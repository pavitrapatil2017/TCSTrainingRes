package Java8features_day5;

public class AnonymousType3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Thread t12 = new Thread( new Runnable()
	        {
			  @Override
	            public void run()
	            {
	                System.out.println("Child Thread");
	            }
	        });
	          
	        t12.start();
	          
	        System.out.println("Main Thread");
	}
	
	

}

package Java8features_day5;

//Thread implements Runnable -run
//Runnable



class MyThreadClass extends Thread
{
	public void run()
	{
	for(int i=0;i<100;i++)	
		System.out.println("Hello started with thread"+i+" "+Thread.currentThread().getName());
	}
}

class SampleThread implements Runnable
{
	public static void display()
	{
		for(int i=500;i<700;i++)	
			System.out.println("Hello sample thread working"+i+"  "+Thread.currentThread().getName());
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		display();
		}
	
}
public class ThreadExample {
	public static void main(String[] a) throws InterruptedException
	{
		MyThreadClass myclass=new MyThreadClass();//thread
		myclass.setName("First_Thread");
		myclass.start();//it will call the run method
		
		Thread.sleep(2000);
		Thread.currentThread().setName("Second_Thread");
		for(int i=200;i<400;i++)
			System.out.println("inside main by main thread"+i+" "+Thread.currentThread().getName());
		
		SampleThread t1=new SampleThread();
		Thread thread=new Thread(t1);
		thread.setName("Third_Thread");
		thread.start();
		
	}
	

}

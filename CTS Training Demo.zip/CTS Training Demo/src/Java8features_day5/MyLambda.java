package Java8features_day5;

interface MyData
{
	void display(String message);
}
interface Addition
{
	void add(int a, int b);
}
interface Square
{
	int numSquare(int num);
}

public class MyLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	MyData MyVariable=(msg)->System.out.println("the userdefined message is"+msg);
	//new Sample.display();
	
	MyVariable.display("welcome to java lambda expression");
	
	Addition addition=(a,b)->{
		int r=a+b;
		System.out.println("result of addition"+r);
	};
	
	addition.add(100,200);
	
	addition.add(1000, 2000);
	
	Square result=(number1)->{return number1 * number1;};
	
	System.out.println(result.numSquare(6));
	}

}

/*class sample implements MyData
{
	public void display()
	{
		System.out.println("Hello World");
	}
}*/
package Java8features_day5;

public class AnonymousType1Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //Here we are using Anonymous Inner class
        //that extends a class i.e. Here a Thread class
        Thread t = new Thread()
        {
            public void run()
            {
                System.out.println("Child Thread");
            }
        };
        t.start();
        System.out.println("Main Thread");
	}

}
class MyThread extends Thread
{
	public void run()
	{
		System.out.println("Child Thread");
	}
}

Thread t=new MyThread();
t.start();
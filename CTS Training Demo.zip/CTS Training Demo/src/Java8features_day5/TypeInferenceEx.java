package Java8features_day5;

public class TypeInferenceEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringLengthLambda myLambda=(s)->s.length();
		System.out.print(myLambda.getLength("Hello Lambda"));
		
		printLambda(s->s.length());
	}
	public static void printLambda(StringLengthLambda l)
	{
		System.out.print(l.getLength("Hello Lambda"));
	}
interface StringLengthLambda
{
	int getLength(String s);
}
}

package Java8features_day5;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class UnitExericise {
public static void main(String[] a)
{
	List<Person> people=Arrays.asList(
			new Person("charles","Dickens",60),
			new Person("charles","Dickens",60),
			new Person("charles","Dickens",60),
			new Person("charles","Dickens",60),
			new Person("charles","Dickens",60)
			
			);
		//Step: sort list by last name
	Collections.sort(people, new Comparator<Person>() {
		@Override
		public int compare(Person o1, Person o2)
		{
			return o1.getLastName().compareTo(o2.getLastName());
		}
	});
	
	//Step 2: print all the elements in the list
	printAll(people);
	
	//Step 3: create a method that prints all the people that have last name beginning with c
	
	printLastNameBegWithC(people);
	
	/*printConditionaly(people, new Condition() {
		@Override
		public boolean test(Person p)
		{
			return p.getLastName().startsWith("C");
		}
	});*/
}

private static void printAll(List<Person> people)
{
	for(Person p: people)
	{
		System.out.println(p);
	}
}

/*private static void printLastNameBegWithC(List<Person> people)
{
	for(Person p: people)
	{
		if(p.getLastName().startsWith("C"))
		{
			System.out.println(p);
		}
	}
}*/
}
interface Condition
{
	boolean test(Person p);
}
//https://www.youtube.com/watch?v=MqsCdbMQjWc&list=PLqq-6Pq4lTTa9YGfyhyW2CqdtW9RtY-I3&index=14

package Java8features_day5;

public class Assignment5 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}

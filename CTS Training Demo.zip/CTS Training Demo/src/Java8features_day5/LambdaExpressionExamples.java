package Java8features_day5;


public class LambdaExpressionExamples {
	
	public void greet(Greeting greeting)
	{
		greeting.perform();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LambdaExpressionExamples ex=new LambdaExpressionExamples();
		HelloWorldGreeting helloworldGreeting=new HelloWorldGreeting();
		ex.greet(helloworldGreeting);
		
		Greeting greeting=()->System.out.println("HelloWorld");
		greeting.perform();
		
		
		ex.greet(()->System.out.println("Hello...."));
	}

}

/**
 * 
 */
package Java8features_day5;

/**
 * @author Admin
 *
 */
interface Greeting {
public void perform();
}

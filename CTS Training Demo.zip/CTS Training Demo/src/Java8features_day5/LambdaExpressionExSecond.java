package Java8features_day5;

interface MyAdd
{
	void add(int a, int b);
}
public class LambdaExpressionExSecond {
public static void main(String[] a)
{
	MyAdd add1=(int a1, int b)->System.out.println(a1+b);
	
add1.add(100,200);
}
}

package Java8features_day5.defaultmethodpack;

interface PrintDemo {
	  
    // Static Method
    static void hello()
    {
        System.out.println("Called from Interface PrintDemo");
    }
}
public class InterfaceStaticMethodEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Call Interface method as Interface
        // name is preceeding with method
        PrintDemo.hello();
  
        // Call Class static method
        hello();
    }
  
    // Class Static method is defined
    static void hello()
    {
        System.out.println("Called from Class");
    }
}



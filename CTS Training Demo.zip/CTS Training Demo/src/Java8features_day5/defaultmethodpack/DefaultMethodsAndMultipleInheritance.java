package Java8features_day5.defaultmethodpack;

//A simple Java program to demonstrate multiple
//inheritance through default methods.

//Important Points:

//Interfaces can have default methods with implementation in Java 8 on later.
//Interfaces can have static methods as well, similar to static methods in classes.
//Default methods were introduced to provide backward compatibility for old interfaces
//so that they can have new methods without affecting existing code.
interface TestInterface11
{
 // default method
 default void show()
 {
     System.out.println("Default TestInterface1");
 }
}

interface TestInterface2
{
 // Default method
 default void show()
 {
     System.out.println("Default TestInterface2");
 }
}

public class DefaultMethodsAndMultipleInheritance  implements TestInterface11, TestInterface2{

	// Overriding default show method
    public void show()
    {
        // use super keyword to call the show
        // method of TestInterface1 interface
        TestInterface11.super.show();
  
        // use super keyword to call the show
        // method of TestInterface2 interface
        TestInterface2.super.show();
    }
  
    public static void main(String args[])
    {
        TestClass d = new TestClass();
        d.show();
    }
}

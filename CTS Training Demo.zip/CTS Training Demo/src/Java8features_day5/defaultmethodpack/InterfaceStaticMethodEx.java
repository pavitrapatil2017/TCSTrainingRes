package Java8features_day5.defaultmethodpack;

interface NewInterface {
	  
    // static method
    static void hello()
    {
        System.out.println("Hello, New Static Method Here");
    }
  
    // Public and abstract method of Interface
    void overrideMethod(String str);
}


public class InterfaceStaticMethodEx implements NewInterface{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceStaticMethodEx interfaceDemo = new InterfaceStaticMethodEx();
		  
	        // Calling the static method of interface
	        NewInterface.hello();
	  
	        // Calling the abstract method of interface
	        interfaceDemo.overrideMethod("Hello, Override Method here");
	    }
	  
	    // Implementing interface method
	  
	    @Override
	    public void overrideMethod(String str)
	    {
	        System.out.println(str);
	    }
	}



package Java8features_day5.defaultmethodpack;

public class DefaultStaticEx2 {
	
	 public static void main(String args[]) {
	      Vehicle1 vehicle = new Car1();
	      vehicle.print();
	   }
}

	interface Vehicle1 {

	   default void print() {
	      System.out.println("I am a vehicle!");
	   }
		
	   static void blowHorn() {
	      System.out.println("Blowing horn!!!");
	   }
	}

	interface FourWheeler1 {

	   default void print() {
	      System.out.println("I am a four wheeler!");
	   }
	}

	class Car1 implements Vehicle1, FourWheeler1 {

	   public void print() {
	      Vehicle1.super.print();
	      FourWheeler1.super.print();
	      Vehicle1.blowHorn();
	      System.out.println("I am a car!");
	   }
	}
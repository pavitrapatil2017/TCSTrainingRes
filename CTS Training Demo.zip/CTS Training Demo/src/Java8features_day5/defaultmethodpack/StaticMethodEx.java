package Java8features_day5.defaultmethodpack;

//The interfaces can have static methods as well which is similar to 
//static method of classes.

interface TestInterface1
{
    // abstract method
    public void square (int a);
  
    // static method
    static void show()
    {
        System.out.println("Static Method Executed");
    }
}

public class StaticMethodEx implements TestInterface1{

	// Implementation of square abstract method
	public void square (int a)
	{
	    System.out.println(a*a);
	}

	public static void main(String args[])
	{
		TestInterface1 d = new StaticMethodEx();
	    d.square(4);

	    // Static method executed
	    TestInterface1.show();
	}
	
}

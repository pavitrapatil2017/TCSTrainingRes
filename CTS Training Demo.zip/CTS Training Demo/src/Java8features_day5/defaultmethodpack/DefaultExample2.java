package Java8features_day5.defaultmethodpack;

interface Vehicle {

	   default void print() {
	      System.out.println("I am a vehicle!");
	   }
	}

 interface fourWheeler {

	   default void print() {
	      System.out.println("I am a four wheeler!");
	   }
	}

 class Car implements Vehicle, fourWheeler {

	   /*public void print() {
	      System.out.println("I am a four wheeler car vehicle!");
	   }*/
	 
	 public void print() {
	      Vehicle.super.print();
	      fourWheeler.super.print();
	   }
	}
public class DefaultExample2 {
	public static void main(String args[]) {
	      Vehicle vehicle = new Car();
	      vehicle.print();
	      
	     /* fourWheeler fw=new Car();
	      fw.print();*/
	   }
}

package Inheritanceex;

public class Child1 extends Child {
protected int num3;


public Child1() {
	super();//child
}

public Child1(int num1,int num2)
{
	this.num1=num1;
	this.num2=num2;
}

public Child1(int num1,int num2, int num3) {
	//super(num1,num2);
	this(num1,num2);
	/*this.num1=num1;
	this.num2=num2;*/
	this.num3 = num3;
}
@Override
public String  displayInfo()
{
	
	return super.displayInfo()+" "+num3;
}
public int getNum3()
{
	return num3;
}

}

package Inheritanceex;

public class Child extends Parent {
	
	protected int num2;
	public Child()
	{
		super();
		num2=50;
		System.out.println("child default");
	}
	public Child(int num2)
	{
		//super();
		this.num2=num2;
		System.out.println("child default");
	}
	public Child(int num1,int num2)
	{
		super(num1);
		//this.num1=num1;
		this.num2=num2;
		System.out.println("child para");
	}
	@Override
	public String displayInfo()
	{
		 return super.displayInfo()+" "+num2;
	}
	public void test()
	{
		System.out.println("test");
	}

}

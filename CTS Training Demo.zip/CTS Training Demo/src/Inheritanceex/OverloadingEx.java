package Inheritanceex;

public class OverloadingEx {
	int num1, num2, num3;
	float fnum1, fnum2, fnum3;
	double dnum1, dnum2, dnum3;
	
	double result;
	

	public OverloadingEx(int num1, int num2, int num3, float fnum1, float fnum2, float fnum3, double dnum1,
			double dnum2, double dnum3) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.num3 = num3;
		this.fnum1 = fnum1;
		this.fnum2 = fnum2;
		this.fnum3 = fnum3;
		this.dnum1 = dnum1;
		this.dnum2 = dnum2;
		this.dnum3 = dnum3;
	}

	public void addition()
	{
		System.out.println("no arg method");
		result= num1+num2+num3+fnum1+fnum2+fnum3+dnum1+dnum2+dnum3;
	}
	public void display()
	{
		System.out.println(result);
	}

	public void testVararg(int ...var)//array
	{
		int sum=0;
		
		for(int r : var)
		{
			sum += r;//sum=sum+r;
		}
		System.out.println("var arg result is"+sum);
	}
	
	public void testVararg(float ...var)//array
	{
		float sum=0.0f;
		
		for(float r : var)
		{
			sum += r;//sum=sum+r;
		}
		System.out.println("float var arg result is"+sum);
	}
	
	
	
	public void addition(int n1, int n2)
	{
		System.out.println("two int arg method");
		result= num1+num2+num3+n1+n2;
	}
	public void addition(float n1, float n2)
	{
		result= num1+num2+num3+n1+n2;
	}
	public void addition(double n1, double n2)
	{
		result= num1+num2+num3+n1+n2;
	}
	public void addition(int n1, float n2)
	{
		result= num1+num2+num3+n1+n2;
	}
	public void addition(float n1, int n2)
	{
		result= num1+num2+num3+n1+n2;
	}
	public void addition(float n1, float n2,float n3)
	{
		result= fnum1+fnum2+fnum3+n1+n2;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OverloadingEx ex = new OverloadingEx();
		ex.addition();
		ex.display();
		
		ex.addition(100,200);
		ex.display();
		
		ex.testVararg(10,20,30,40,50,60,70,80,90,100);
		
		ex.testVararg(10.0f,20.0f,30.0f,40.0f,50.0f,60.0f,70.0f,80.0f,90.0f,100.0f);
		
	}

	public OverloadingEx() {
		super();
	}

}

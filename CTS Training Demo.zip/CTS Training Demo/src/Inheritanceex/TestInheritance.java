package Inheritanceex;

public class TestInheritance {
	/*public static double Tax(Parent parent)//polymorphic arguement
	{
		if(parent instanceof Parent)
		{
			Parent p=(Parent)parent;
			return p.num1*0.01;
		}else if(parent instanceof Child)
		{
			Child child=(Child)parent;
			return child.num2 * 0.02;
		}else if(parent instanceof Child1)
		{
			Child1 child1=(Child1)parent;
			return child1.num3*0.3;
		}
		return 0.001;
	}*/
	public static void main(String[] arg)
	{
		//Child child=new Child(100,123);
		
		int n=10;
		long l=n;
		n=(int)l;
		Parent  parent=new Child1(200,300,400);//upcasting --automatically 
		//System.out.println(child.displayInfo());
		//Parent parent=new Child1(100,200);
		System.out.println(parent.displayInfo());
		/*Child c1=(Child)parent;
		c1.test();*/
		/*Child1 child1=(Child1)parent;
		System.out.println(child1.getNum3());
		parent=new Child(40,30);*/
		
		//double result=TestInheritance.Tax(parent);
		//System.out.println(result);
		
	}

}

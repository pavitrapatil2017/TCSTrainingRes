package Inheritanceex;

public class Parent {
	
	protected int num1;
	
	public Parent()
	{
		num1=100;
		System.out.println("default base");
	}
	public Parent(int num1)
	{
		this.num1=num1;
		System.out.println("para base");
	}
	
	String displayInfo()
	{
		return num1+" ";
	}

}

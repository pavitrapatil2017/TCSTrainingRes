package singletonpack;

public class SingletonDesignEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Printer printer = Printer.getPrinter();
printer.printDetails();

Printer printer1=Printer.getPrinter();
printer1.printDetails();

	}

}

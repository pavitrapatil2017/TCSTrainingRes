package singletonpack;

public class Printer {
	
	private static final Printer p=new Printer();
	
	private Printer()
	{
		
	}
	public static Printer getPrinter()
	{
		return p;
	}
	public void printDetails()
	{
	System.out.println("Printing");	
	}

}

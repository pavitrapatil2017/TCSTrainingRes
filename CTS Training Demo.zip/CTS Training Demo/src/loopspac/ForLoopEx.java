package loopspac;

public class ForLoopEx {
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0; i<10; i++)
		{
			System.out.println("Hello all good morning");
		}
		int i=0,j=0;
		for(; i<=10 ;  )
		{
			System.out.println (j*i);
			i++;
			j++;
		}
		
		int number=1;
		for (int k=0; k<3; k++) {
			for (int l=0; l<=5; l++, number++) {
				if (number % 5 ==0)
				{
					break;
				}else
				{
					System.out.print (number);
					continue;
				}
				
			}
			System.out.println();		
		}
		
	}

}

package polymorphism;

public class OverloadingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition addition=new Addition();
		addition.add();
		addition.displayResult();
		Addition addition1=new Addition(10,20,30,34.76f,76.89f,90.87f,0.0f);
		addition1.add();
		addition1.displayResult();
		addition1.add(1234);
		addition1.displayResult();
		addition1.add(10,34.56f);
		addition1.displayResult();
		addition1.add(100.87f,34);
		addition1.displayResult();
		Addition addition2=new Addition(10,20,30);
		addition2.add();
		addition2.displayResult();
	}

}

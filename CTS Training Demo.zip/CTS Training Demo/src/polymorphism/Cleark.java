package polymorphism;

public class Cleark extends Employee{

	public Cleark() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cleark(String empName, int empId, double salary) {
		super(empName, empId, salary);
		// TODO Auto-generated constructor stub
	}

}

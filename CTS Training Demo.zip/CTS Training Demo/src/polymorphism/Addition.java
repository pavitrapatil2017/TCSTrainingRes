package polymorphism;

public class Addition {
int num1,num2,num3;
float f1,f2,f3;
float result;

public Addition() {
	super();
}

public Addition(int num1, int num2, int num3, float f1, float f2, float f3,float res) {
	super();
	this.num1 = num1;
	this.num2 = num2;
	this.num3 = num3;
	this.f1 = f1;
	this.f2 = f2;
	this.f3 = f3;
	result=res;
}
public Addition(int num1, int num2, int num3)
{
	this.num1=num1;
	this.num2=num2;
	this.num3=num3;
}
public Addition(float num1, float num2, float num3)
{
	this.f1=num1;
	this.f2=num2;
	this.f3=num3;
}
void add(){
	System.out.println("Empty arg");
	result=num1+num2+num3+f1+f2+f3;
}
void add(int number) {
	System.out.println("int para");
	result=num1+num2+num3+f1+f2+f3+number;
}
void add(int number,float fnumber) {
	System.out.println("int and float");
	result=num1+num2+num3+f1+f2+f3+number+fnumber;
}
float add(float fnumber,int number) {
	System.out.println("float and int");
	result=num1+num2+num3+f1+f2+f3+number+fnumber;
	return result;
}
void displayResult()
{
	System.out.println(result);
}

}

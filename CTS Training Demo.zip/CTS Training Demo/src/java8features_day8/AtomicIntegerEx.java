package java8features_day8;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicIntegerEx {
	public static void main(String[] a)
	{
		AtomicInteger atomicInteger=new AtomicInteger(100);
		System.out.println(atomicInteger.getAndAdd(200));
		System.out.println(atomicInteger);
		System.out.println(atomicInteger.decrementAndGet());
		atomicInteger.compareAndSet(299, 310);
		System.out.println(atomicInteger);
		
	}

}

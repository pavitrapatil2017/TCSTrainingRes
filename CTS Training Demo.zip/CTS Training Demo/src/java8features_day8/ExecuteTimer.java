package java8features_day8;

import java.util.Timer;

public class ExecuteTimer {
	

	public static void main(String[] args){
	       TimerExample te1=new TimerExample("Task1");
	       TimerExample te2=new TimerExample("Task2");

	      Timer t=new Timer();
	      t.scheduleAtFixedRate(te1, 0,1);
	      t.scheduleAtFixedRate(te2, 0,1);
/*try {
	Thread.sleep(1000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	System.out.println("exception"+e.getMessage());*/
	
	System.out.println("ended");
	t.cancel();
	     


}
}
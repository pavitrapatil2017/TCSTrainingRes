package abstractpac;

public abstract class Shape {
	String name;
	int id;
	
	
	
	public Shape() {
		super();
	}



	public Shape(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}



	public  abstract void draw();
	
	

}

package abstractpac;

public class TestAbstract {
	
	public static void main(String[] args)
	{
		Shape sh=new Shape();
		Shape shape=new Rectangle(100,50);
		shape.draw();
		
		shape=new Square(50);
		shape.draw();
		
		
	}
	
	

}

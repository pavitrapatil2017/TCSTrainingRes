package abstractpac;

public class Rectangle extends TwoD {

	int length, width; 
	//float radious;

	
	public Rectangle(int length, int width) {
		super();
		this.length = length;
		this.width = width;
	}
	
	public void draw()
	{
		System.out.println("Rectangle with specified length and width");
	}
	
	
}

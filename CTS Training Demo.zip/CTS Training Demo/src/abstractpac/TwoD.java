package abstractpac;

public abstract class TwoD extends Shape{
	

}

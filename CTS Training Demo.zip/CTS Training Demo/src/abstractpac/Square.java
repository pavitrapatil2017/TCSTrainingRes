package abstractpac;

public class Square extends Shape{

	int side;

	public Square(int side) {
		super();
		this.side = side;
	}
	public void draw()
	{
		System.out.println("square with side");
	}

}

package abstractpac;

public class FinalVariableEx {
	
	public static void main(String[] a)
	{
		Student s=new Student();//cname==mvit
		Student s1=new Student();//cname==mvit
		
	}
	
	

}

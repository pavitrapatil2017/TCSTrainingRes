package abstractpac;

public class Student {
	String name;
	int id;
	static final String cname="mvit";
	
	Student()
	{
		//cname="MVIT";
		
	}
	
	
}

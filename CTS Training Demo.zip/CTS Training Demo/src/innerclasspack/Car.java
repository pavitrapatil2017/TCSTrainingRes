package innerclasspack;

public class Car {
	
	/* class Engine
	{
		void start()
		{
			System.out.println("started");
		}
	}*/
	public void start()
	{
		class Engine
		{
			void start()
			{
				System.out.println("car engine started");
			}
		};
		
		new Engine().start();
	}
}
	
	/*Engine engine;
	
	Car()
	{
		engine=new Engine();
		
	}
	void startup()
	{
		engine.start();
	}

}

class Engine
{
	void start()
	{
		System.out.println("started");
	}
}
*/
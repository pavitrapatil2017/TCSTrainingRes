package innerclasspack;

public class Employee {
	String name;
	Address address;
	
	class Address
	{
		
		String city;
		String state;
		String pincode;
		
		public Address() {
			super();
			
		}

		public Address(String city, String state, String pincode) {
			super();
			this.city = city;
			this.state = state;
			this.pincode = pincode;
		}

		@Override
		public String toString() {
			return "Address [city=" + city + ", state=" + state + ", pincode=" + pincode + "]";
		}
		
	}
	public Employee() {
		super();
	
	}
	public Employee(String name, Address address ) {
		super();
		this.name = name;
		this.address=address;
	}
	public Employee(String name) {
		super();
		this.name = name;
		
	}
	
	public void displaydetails()
	{
		System.out.println(name+" "+address);
	}
	
}

package innerclasspack;

public class Sample2 extends Sample1 {
	public void display(String message)
	{
		System.out.println("Hello");
	}
}

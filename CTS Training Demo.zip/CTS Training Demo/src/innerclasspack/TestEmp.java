package innerclasspack;

public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee=new Employee("mahesh");
		Employee.Address add=employee.new Address("bang","karn","65632");
		
	System.out.println(employee.name+" "+add);
	}

}

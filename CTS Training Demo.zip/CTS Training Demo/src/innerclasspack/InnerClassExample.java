package innerclasspack;

public class InnerClassExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Car car=new Car();
car.start();
//Car.Engine carengine= car.new Engine();
//carengine.start();

//car.start();
	}

}

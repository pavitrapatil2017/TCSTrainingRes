package innerclasspack;

public class Sample {
	String name;
	String id;
	
	Sample(String name, String id)
	{
		this.name=name;
		this.id=id;
	}
	
	public String display()
	{
		return name+" "+id;
	}

}

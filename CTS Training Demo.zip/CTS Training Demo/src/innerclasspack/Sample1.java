package innerclasspack;

public class Sample1 {
	public void display(String message)
	{
		System.out.println("Hello");
	}

}

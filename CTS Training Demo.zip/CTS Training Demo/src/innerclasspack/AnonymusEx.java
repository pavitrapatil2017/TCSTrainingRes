package innerclasspack;

public class AnonymusEx  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
/*	new Sample1()
			{
				@Override
				public void display(String msg)
				{
					System.out.println("annoynus block"+msg);
				}
			}.display("welcome to ....");
			
			//sample123.display("welcome to ....");
*/		
Object obj=new Object()
{
	public String toString()
	{
		return "Hello World";
	}
	public boolean equals(String s1)
	{
		return  new String("Hello").equals(s1);
	}
};

System.out.println(obj.toString());
System.out.println("1111111111"+obj.equals("Hello"));

Sample sample=new Sample("meena","100")
{
	public String display()
	{
		return "Customized"+this.name+" "+this.id;
	}
};

System.out.println(sample.display());

System.out.println(new Sample("Shiva","200")
{
	public String display()
	{
		return "Customized"+this.name+" "+this.id;
	}
}.display());





	}

}

package genericpack;

public class GenericDemo<T,E> {
	
	T num1,num2;
	E m1, m2;
	
	
	
	
	public E getM1() {
		return m1;
	}



	public void setM1(E m1) {
		this.m1 = m1;
	}



	public E getM2() {
		return m2;
	}



	public void setM2(E m2) {
		this.m2 = m2;
	}



	public T getNum1() {
		return num1;
	}



	public void setNum1(T num1) {
		this.num1 = num1;
	}



	public T getNum2() {
		return num2;
	}



	public void setNum2(T num2) {
		this.num2 = num2;
	}



	public GenericDemo(T num1, T num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericDemo<Integer,String> gn=new GenericDemo<Integer,String>(20,40);
		gn.setM1("First");
		gn.setM2("Second");
		Integer result=gn.getNum1()+gn.getNum2();
		
		System.out.println("message"+" "+ gn.getM1()+" "+gn.getM2()+" "+result);
		
GenericDemo<Float,Double> flt=new GenericDemo<Float,Double>(20.87f,40.87f);
		
		Float result1=flt.getNum1()+gn.getNum2();
		
		System.out.println(result1);
		
		
GenericDemo<Double,Long> gnd=new GenericDemo<Double,Long>(20.87,60.45);
		
		Double res=gnd.getNum1()+gnd.getNum2();
		
		System.out.println(res);
		
		
		
	}

}

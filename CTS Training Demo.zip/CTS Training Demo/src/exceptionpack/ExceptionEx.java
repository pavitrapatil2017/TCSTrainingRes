package exceptionpack;

import java.util.Scanner;

public class ExceptionEx {
	
	public static void displayArray()
	{
		int[] arr= {12,34,34,56};
		System.out.println(arr[6]);
		
	}
	
	public static void divideNum()
	{
		int num1=100,num2=0,res=0;
		System.out.println("About to execute");
		res=num1/num2;
		System.out.println("result"+res);
	}

	public static void main(String[] args) {
		
	
		try {
			divideNum();
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

		// TODO Auto-generated method stub

		
		try {
			
			displayArray();
		
		}catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("message"+ex.getClass());
		}catch(Exception ex)
		{
			System.out.println("Message here"+ex.getMessage());
		}finally
		{
			//System.out.println("result:"+ res);
			
		}
		
		Scanner sn=new Scanner(System.in);
		int message=sn.nextInt();
		System.out.println(message);
				
		
		
	}

}

package exceptionpack;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter fwrite=new FileWriter("Hello.txt");
		fwrite.write("a");
		fwrite.close();
	}

}

package exceptionpack;

public class AgeValidation {

	int age;
	
	AgeValidation(int age)
	{
		this.age=age;
	}
	
	public void validate() throws InvalidAgeException
	{
		if(age<=0)
			throw new InvalidAgeException("Age should be greater 0");
		else 
			System.out.println("Valid age");
	}
	public static void main(String[] arg)
	{
		AgeValidation ageValidation=new AgeValidation(-1);
		try {
		ageValidation.validate();
		}catch(InvalidAgeException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
}

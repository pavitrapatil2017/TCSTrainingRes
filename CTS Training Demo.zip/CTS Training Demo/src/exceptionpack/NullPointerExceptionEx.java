package exceptionpack;

public class NullPointerExceptionEx {
public static void main(String[] arg)
{
	String str=null;
	try
	{
	 str=null;
	 str.concat("Hello");
	}catch(NullPointerException ex)
	{
		System.out.println("check ---Something returns the null pointer"+ex.getMessage()); 
	}finally {
	
	System.out.println(str);
	}
}
}

package exceptionpack;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Parent {
public void readData() throws FileNotFoundException, IOException
{
	FileReader fr=new FileReader("Hello.txt");
	int r=fr.read();
	fr.close();
}
}

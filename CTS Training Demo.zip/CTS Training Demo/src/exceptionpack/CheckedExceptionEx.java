package exceptionpack;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CheckedExceptionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*FileWriter fr=null;
		try {
		fr=new FileWriter("Hello.txt");
		fr.write("hello");
		}catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}finally
		{
			
			fr.close();	
		}*/
		
		try(FileReader fr=new FileReader("Hello.txt");FileWriter  fw=new FileWriter("Hello.txt");CloseableSample clx=new CloseableSample())
		{
			System.out.println((char)fr.read());
		}catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
		}catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}catch(Exception ex1)
		{
			
		}
		
		
	}

}

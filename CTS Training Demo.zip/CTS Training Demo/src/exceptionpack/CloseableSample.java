package exceptionpack;

import java.io.IOException;

public class CloseableSample implements AutoCloseable {

	public void display() throws IOException
	{
		
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}
}

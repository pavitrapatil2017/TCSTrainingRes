package collectionpack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ListDemo {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
//List list=new ArrayList();
		
		List list=new LinkedList();
		
list.add(100);//autoboxing --primitive to object casting 
list.add(34.45f);
list.add("neha");
list.add('G');
list.add(true);
list.add(true);

System.out.println(list);

List list1=new ArrayList();
list1.addAll(list);
list1.add("testing");
list1.add(false);

System.out.println(list1);

list1.removeAll(list);

System.out.println(list1);

System.out.println(list1.size());

System.out.println(list.remove("neha"));

System.out.println(list);


ListIterator iterator=list.listIterator();

while(iterator.hasNext()){iterator.next();}

while(iterator.hasPrevious())
{
System.out.println("value"+iterator.previous());
	
/*if(obj instanceof Integer)
{
	int value=(Integer)obj;
}	else if()
	System.out.println(iterator.next());*/
}







	}

}

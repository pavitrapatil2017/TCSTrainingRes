package collectionpack;
import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;


public class SetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Set set=new HashSet();
set.add(100);
set.add(200);
set.add(200);
set.add('A');
set.add("Ram");
set.add(null);
set.add(null);
set.remove('A');

System.out.println(set);


Set<Integer> set1=new TreeSet<>();
set1.add(100);
set1.add(200);
set1.add(200);
set1.add(50);
set1.add(240);
//set1.add(null);
//set1.add('h');
//set1.('A');

System.out.println(set1);


/*Set<Student> studentset=new HashSet<>();
studentset.add(new Student("nisha",100));
studentset.add(new Student("komal",300));

System.out.println(studentset);
*/
	}

}

package collectionpack;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.HashMap;

public class MapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Map<String,String> map=new HashMap<>();
map.put("username", "pavikp");
map.put("password", "12345");
map.put("firstname", "pavitra");
map.put("lastname", "nagaral");
map.put(null,"hello");
map.put(null,"hi");
map.put("one", null);
map.put("two", null);


System.out.println(map);

Set<String> set=map.keySet();
System.out.println(set);

Collection<String> val=map.values();

System.out.println(val);
	}

}

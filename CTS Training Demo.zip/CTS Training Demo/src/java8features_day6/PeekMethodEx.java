package java8features_day6;

import java.util.Stack;

public class PeekMethodEx {
	public static void main(String[] a) {
	/*Stack<String> STACK = new Stack<String>();
	  
    // Use push() to add elements into the Stack
    STACK.push("Welcome");
    STACK.push("To");
    STACK.push("Geeks");
    STACK.push("For");
    STACK.push("Geeks");

    // Displaying the Stack
    System.out.println("Initial Stack: " + STACK);

    // Fetching the element at the head of the Stack
    System.out.println("The element at the top of the"
                       + " stack is: " + STACK.peek());

    String str=STACK.pop();
    System.out.println(str);
    // Displaying the Stack after the Operation
    System.out.println("Final Stack: " + STACK);*/
    
    
      Stack<Integer> STACK = new Stack<Integer>();
  
        // Use push() to add elements into the Stack
        STACK.push(10);
        STACK.push(15);
        STACK.push(30);
        STACK.push(20);
        STACK.push(5);
  
        // Displaying the Stack
        System.out.println("Initial Stack: " + STACK);
  
        // Fetching the element at the head of the Stack
        System.out.println("The element at the top of the"
                           + " stack is: " + STACK.peek());
  
        // Displaying the Stack after the Operation
        System.out.println("Final Stack: " + STACK);
     
	}

}

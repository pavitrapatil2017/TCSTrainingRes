package java8features_day6;
import java.util.List;
import java.util.Arrays;

public class DistinctMethodEx {
	
	public static void main(String[] args)
    {
  
        // Creating a list of integers
        List<Integer> list = Arrays.asList(1, 1, 2, 3, 3, 4, 5, 5);
  
        System.out.println("The distinct elements are :");
  
        // Displaying the distinct elements in the list
        // using Stream.distinct() method
        list.stream().distinct().forEach((val)->System.out.print(val));
        
        // Creating a list of strings
        List<String> list1 = Arrays.asList("Geeks", "for", "Geeks",
                                          "GeeksQuiz", "for", "GeeksforGeeks");
  
        System.out.println("The distinct elements are :");
  
        // Displaying the distinct elements in the list
        // using Stream.distinct() method
        list1.stream().distinct().forEach(System.out::println);
         
         
       // Creating a list of strings
        List<String> list2 = Arrays.asList("Geeks", "for", "Geeks",
                                          "GeeksQuiz", "for", "GeeksforGeeks");
  
        // Storing the count of distinct elements
        // in the list using Stream.distinct() method
        long Count = list.stream().distinct().count();
  
        // Displaying the count of distinct elements
        System.out.println("The count of distinct elements is : " + Count);
    }
         
        
        
    }



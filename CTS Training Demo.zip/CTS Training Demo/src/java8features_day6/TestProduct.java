package java8features_day6;

import java.util.function.Consumer;





public class TestProduct {
	  public static void main(String[] args) {
		    Consumer<Product> updatePrice = p -> p.setPrice(5.9);
		    Product p = new Product();
		    updatePrice.accept(p);
		    p.printPrice();
		  }

}

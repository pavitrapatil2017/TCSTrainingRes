package java8features_day6;

import java.util.Arrays;
import java.util.List;

public class SortedMethodEx2 {
	 // Creating a list of strings
	public static void main(String[] a) {
    List<String> list = Arrays.asList("Geeks", "For",
                 "GeeksQuiz", "GeeksforGeeks", "GFG");

    System.out.println("The sorted stream is : ");

    // displaying the stream with elements
    // sorted in their natural order
    list.stream().sorted().forEach(System.out::println);
    
 // Creating a list of integers
    List<Integer> list1 = Arrays.asList(-9, -18, 0, 25, 4);

    System.out.println("The sorted stream is : ");

    // displaying the stream with elements
    // sorted in natural order
    list1.stream().sorted().forEach(System.out::println);
	}

}

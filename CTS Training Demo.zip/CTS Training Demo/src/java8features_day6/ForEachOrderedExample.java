package java8features_day6;
import java.util.List;
import java.util.stream.Stream;
import java.util.Arrays;

public class ForEachOrderedExample {
	public static void main(String[] args) {
		  
	    // Creating a list of Integers
	    List<Integer> list = Arrays.asList(10, 19, 20, 1, 2);
	      
	    // Using forEachOrdered(Consumer action) to 
	    // print the elements of stream in encounter order
	    list.stream().forEachOrdered(System.out::println);
	    
	    
	     List<String> list1 = Arrays.asList("GFG", "Geeks", 
                             "for", "GeeksforGeeks");
      
    // Using forEachOrdered(Consumer action) to 
    // print the elements of stream in encounter order
    list1.stream().forEachOrdered(System.out::println);
	     
	    
	    // Creating a Stream of Strings
	    Stream<String> stream = Stream.of("GFG", "Geeks", 
	                             "for", "GeeksforGeeks");
	      
	    // Using forEachOrdered(Consumer action) 
	    stream.flatMap(str-> Stream.of(str.charAt(2)))
	          .forEachOrdered(System.out::println);
	      
	  
	}

}

package java8features_day6;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.stream.Stream;

public class ParallelStreamExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 // Create a File object 
        File fileName = new File("M:\\Documents\\Textfile.txt");
          
        // Create a Stream of String type
        // Using the lines() method to read one line at a time
        // from the text file
        Stream<String> text = Files.lines(fileName.toPath());
          
        // Use StreamObject.parallel() to create parallel streams
        // Use forEach() to print the lines on the console
        text.parallel().forEach(System.out::println);
        
     // Create a File object
        /*File fileName = new File("M:\\Documents\\List_Textfile.txt");
  
        // Create a List
        // Using readAllLines() read the lines of the text file
        List<String> text = Files.readAllLines(fileName.toPath());
          
        // Using parallelStream() to create parallel streams
        text.parallelStream().forEach(System.out::println);*/
          
        // Close the Stream
        text.close();
	}

}

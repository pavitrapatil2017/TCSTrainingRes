package java8features_day6.builderpattern;

public class BuilderNeedDemo {
	public static void main(String args[])
    {
        StudentReceiver1 sr = new StudentReceiver1();
        System.out.println(sr.getStudent());
    }

}
/*Output may be:



id = 2, name = Shyam, address = Noida
Another inconsistent output may be
id = 0, name = null, address = null
Note : Try running main method statements in loop(i.e. multiple requests to server simultaneously).
To solve this problem, there is Builder pattern to ensure the thread-safety and atomicity of object creation.
*/
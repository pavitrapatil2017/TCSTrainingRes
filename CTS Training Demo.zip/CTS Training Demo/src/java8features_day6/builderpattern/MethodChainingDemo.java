package java8features_day6.builderpattern;

public class MethodChainingDemo {
    public static void main(String args[])
    {
        Student11 student1 = new Student11();
        Student11 student2 = new Student11();
  
        student1.setId(1).setName("Ram").setAddress("Noida");
        student2.setId(2).setName("Shyam").setAddress("Delhi");
  
        System.out.println(student1);
        System.out.println(student2);
    }
}

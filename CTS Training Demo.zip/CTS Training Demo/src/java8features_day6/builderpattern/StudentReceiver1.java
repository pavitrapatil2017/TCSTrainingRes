package java8features_day6.builderpattern;

/*Need of Builder Pattern : Method chaining is a useful
design pattern but however if accessed concurrently, 
a thread may observe some fields to contain inconsistent values.
Although all setter methods in above example are atomic, 
but calls in the method chaining can lead to inconsistent object
state when the object is modified concurrently. 
The below example can lead us to a Student instance in an
inconsistent state, for example, a student with name Ram and 
address Delhi.*/
public class StudentReceiver1 {
	
    private final Student11 student = new Student11();
    
    public StudentReceiver1()
    {
  
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run()
            {
                student.setId(1).setName("Ram").setAddress("Noida");
            }
        });
  
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run()
            {
                student.setId(2).setName("Shyam").setAddress("Delhi");
            }
        });
  
        t1.start();
        t2.start();
    }
    public Student11 getStudent()
    {
        return student;
    }
}




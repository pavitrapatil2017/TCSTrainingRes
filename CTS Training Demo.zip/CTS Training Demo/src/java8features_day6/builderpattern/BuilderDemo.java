package java8features_day6.builderpattern;

public class BuilderDemo {
	public static void main(String args[])
    {
        StudentReceiver sr = new StudentReceiver();
        System.out.println(sr.getStudent());
    }

}

/*Output is guaranteed to be one of below:
id = 1, name = Ram, address = Noida
OR
id = 2, name = Shyam, address = Delhi
The Builder.newInstance() factory method can also be called with any required arguments to obtain a Builder instance by overloading it. The object of Student class is constructed with the invocation of the build() method.
The above implementation of Builder pattern makes the Student class immutable and consequently thread-safe.
Also note that the student field in client side code cannot be declared final because it is assigned a new immutable object. But it be declared volatile to ensure visibility of shared reference to immutable objects. Also private members of Builder class maintain encapsulation
*/
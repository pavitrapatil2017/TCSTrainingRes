package java8features_day6.builderpattern;

final class Student11 {
	  
    // instance fields
    private int id;
    private String name;
    private String address;
  
    // Setter Methods
    // Note that all setters method
    // return this reference
    public Student11 setId(int id)
    {
        this.id = id;
        return this;
    }
  
    public Student11 setName(String name)
    {
        this.name = name;
        return this;
    }
  
    public Student11 setAddress(String address)
    {
        this.address = address;
        return this;
    }
  
    @Override
    public String toString()
    {
        return "id = " + this.id + ", name = " + this.name + 
                               ", address = " + this.address;
    }
}


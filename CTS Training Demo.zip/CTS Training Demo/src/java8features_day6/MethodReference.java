package java8features_day6;


	interface Sayable{  
	    void say();  
	}  


public class MethodReference {

	   public static void saySomething(){  
			        System.out.println("Hello, this is static method.");  
			    }  
		    public static void main(String[] args) {  
		        // Referring static method  
	        Sayable sayable = MethodReference::saySomething;  
	        
	        /*Sayable sayable1=()->System.out.println("Hello, this is lamba exp)");
	        sayable1.say();*/
	        
	        // Calling interface method  
		        sayable.say();  
		    }  
		}  




 package java8features_day6;

import java.util.function.Supplier;

public class SupplierEx2 {
    public static void main(String[] args) {
        int n = 3;
        display(() -> n + 10);
        display(() -> n + 100);
    }

    static void display(Supplier<Integer> arg) {
        System.out.println(arg.get());

}}

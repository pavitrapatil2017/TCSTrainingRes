package java8features_day6;

import java.util.function.Predicate;

public class PredicateEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       Predicate<Integer> pr = a -> (a > 18); // Creating predicate  
	       System.out.println(pr.test(10));    // Calling Predicate method    

	}

}

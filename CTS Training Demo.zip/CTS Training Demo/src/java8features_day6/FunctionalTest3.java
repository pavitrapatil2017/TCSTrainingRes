package java8features_day6;

import java.util.function.Function;

public class FunctionalTest3 {
    // Function which takes in a number and
    // returns half of it

	public static void main(String[] args)
	{
    Function<Integer,Double> half1 = a1 -> a1 / 2.0;

    try {

        // try to pass null as parameter
        half1 = half1.andThen(null);
    }
    catch (Exception e) {
        System.out.println("Exception thrown "
                           + "while passing null: " + e);
    }
}

}

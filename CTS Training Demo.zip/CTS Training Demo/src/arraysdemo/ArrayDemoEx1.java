package arraysdemo;

public class ArrayDemoEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};//staticarrayinitialization
		 //cars[0] = "Opel";
		 System.out.println(cars.length);
		    System.out.println(cars[0]);
		  
		    for (int i = 0; i < cars.length; i++) {
		    	  System.out.println(cars[i]);
		    	}
		    
		    for (String i : cars) {
		    	  System.out.println(i);
		    	}
		    
	}
	
}

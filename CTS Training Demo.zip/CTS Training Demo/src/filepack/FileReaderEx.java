package filepack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReaderEx {
	
	public static void main(String[] a) throws IOException
	{
		FileReader reader=new FileReader("data.txt");
		BufferedReader breader=new BufferedReader(reader);
		
		String msg=breader.readLine();
		
		System.out.println(msg);
		breader.close();
		reader.close();
		
		FileWriter writer=new FileWriter("Rdata.txt");
		BufferedWriter bwriter=new BufferedWriter(writer);
		
		bwriter.write("Hello");
		
		bwriter.close();
		
	}

}

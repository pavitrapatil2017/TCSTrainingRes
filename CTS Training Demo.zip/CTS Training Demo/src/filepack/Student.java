package filepack;

import java.io.Serializable;

public class Student implements Serializable {
	String name;
	transient int id;
	Teacher teacher;
	
	public Student()
	{
		
	}
	
	public Student(String name, int id,Teacher teacher)
	{
	this.name=name;
	this.id=id;
	this.teacher=teacher;
	}

	public String toString()
	{
		return name+" "+id+" "+teacher;
	}
}

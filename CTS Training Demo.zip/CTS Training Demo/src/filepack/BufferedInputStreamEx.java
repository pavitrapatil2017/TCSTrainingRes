package filepack;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedInputStreamEx {

	public static void main(String[] args) throws FileNotFoundException,IOException {
		// TODO Auto-generated method stub
		FileInputStream fis=new FileInputStream("data.txt");
		BufferedInputStream bufinput=new BufferedInputStream(fis);
		/*byte[] bf=new byte[200];
		fis.read(bf);
		for(byte b : bf )
		{
			System.out.print((char)b);
		}
*/	
		int num=0;
		
		do {
		 num=bufinput.read();
		 System.out.print((char)num);
		}while(num!=-1);
		
		System.out.println("before reset"+bufinput.available());
		
		//bufinput.reset();
		
		int num1=bufinput.read();
		System.out.println("next char is"+(char)num1);
		
		System.out.println("after reset" +bufinput.available());
		
		num1=bufinput.read();
		
		System.out.println("next char is"+(char)num1);
		
		bufinput.mark(2);
		
		bufinput.reset();
		
		num1=bufinput.read();
		
		System.out.println("next char is"+(char)num1);
		
		
		
		
		
	}

}

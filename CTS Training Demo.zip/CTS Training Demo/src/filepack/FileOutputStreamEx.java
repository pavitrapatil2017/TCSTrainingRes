package filepack;

import java.io.FileInputStream;
import java.io.IOException;

public class FileOutputStreamEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream fis=new FileInputStream("data.txt");
		/*byte[] bf=new byte[200];
		fis.read(bf);
		for(byte b : bf )
		{
			System.out.print((char)b);
		}
*/	
		int num=0;
		
		do {
		 num=fis.read();
		 System.out.print((char)num);
		}while(num!=-1);
		
		
	}

}

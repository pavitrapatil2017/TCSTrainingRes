package filepack;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ReadFromKeyboard {

	public static void main(String args[])throws Exception{  
		  
		InputStreamReader r=new InputStreamReader(System.in);  
		BufferedReader br=new BufferedReader(r);  
		  
		System.out.println("Enter your name");  
		String name=br.readLine();  
		System.out.println("Welcome "+name);  
		String id=br.readLine();
		int id1=Integer.parseInt(id);
		System.out.println(id1);
		double marks=Double.parseDouble(br.readLine());
		System.out.println(marks);
		
		
		 }  
}

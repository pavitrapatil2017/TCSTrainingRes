package filepack;

import java.io.Serializable;

public class Teacher implements Serializable{
	String tname;
	int tid;

	public Teacher(String tname, int tid)
	{
		this.tname=tname;
		this.tid=tid;
	}
	
	public String toString()
	{
		return tname+" "+tid;
	}
}

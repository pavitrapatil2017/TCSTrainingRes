package filepack;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectReadAndWrite {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
	ObjectOutputStream output=new ObjectOutputStream(new FileOutputStream("hello.dat"));
	output.writeObject(new Student("nisha",100,new Teacher("Harsha Maam",1000)));//serialization
	output.writeObject(new Student("kavana",200,new Teacher("Meena Maam",2000)));
	output.close();
	
	ObjectInputStream input=new ObjectInputStream(new FileInputStream("hello.dat"));
	Student s1=(Student)input.readObject();//deserialization
	System.out.println(s1);
	s1=(Student)input.readObject();
	System.out.println(s1);
	
	
	}

}

package filepack;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PathExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Path p=Paths.get("D:\\sample\\hello.txt");
		
		System.out.println(p.getNameCount());
		System.out.println(p.getFileName());
		System.out.println(p.getName(0));
		System.out.println(p.getParent());
		System.out.println(p.getRoot());
		
		File file=p.toFile();
		
		Path p1=FileSystems.getDefault().getPath("sample","Myfile.txt");
		
		
		
		
		
		
		
		
		
		
	}

}

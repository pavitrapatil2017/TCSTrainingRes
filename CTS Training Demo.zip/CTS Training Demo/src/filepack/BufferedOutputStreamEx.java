package filepack;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
FileOutputStream fout=new FileOutputStream("bdata.txt");
BufferedOutputStream bfout=new BufferedOutputStream(fout);

bfout.write(100);
bfout.write(101);
bfout.write(102);

bfout.close();

		
	}

}

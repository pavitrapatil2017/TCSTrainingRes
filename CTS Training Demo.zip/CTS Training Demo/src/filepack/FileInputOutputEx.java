package filepack;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileInputOutputEx {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		File file=new File("data.txt");
		
		if(!file.exists())
		{
			file.createNewFile();
		}
		System.out.println(file.canExecute());
		
		System.out.println(file.getAbsolutePath());
		
		System.out.println(file.canExecute());
		
		System.out.println(file.getName());
		
		
		FileOutputStream fout=new FileOutputStream(file);
		byte[] b= {65,66,67,68,69,70};
		
		fout.write(b);
		fout.write(100);
		fout.write(b, 1, 3);
		
		fout.close();
		
	
		
		
	}

}

package interfacepack;

public class TestInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
BasicCalInterface basic=new CalculatorImpl();
basic.add();
basic.mult();
basic.div();
basic.sub();



	}

}

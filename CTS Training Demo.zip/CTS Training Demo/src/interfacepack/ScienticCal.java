package interfacepack;

public interface ScienticCal {
	void findTemp();
}
